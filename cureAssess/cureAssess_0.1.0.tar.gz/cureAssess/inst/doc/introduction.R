## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(cureAssess)
library(survival)
library(dplyr)

## -----------------------------------------------------------------------------
library(cureAssess)
library(survival)
library(dplyr)

## -----------------------------------------------------------------------------
head(survival::nwtco)

## -----------------------------------------------------------------------------
nwtco_dat <- survival::nwtco %>%
  mutate(
    stage_group = case_when(
      stage %in% c(1, 2) ~ "Low risk",
      stage %in% c(3, 4) ~ "High risk",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(stage_group))

## -----------------------------------------------------------------------------
nwtco_surv <- prepare.surv.data(
  data = nwtco_dat,
  time = "edrel",
  status = "rel",
  time_scale = "days_to_years"
)
head(nwtco_surv)

## -----------------------------------------------------------------------------
fit_res <- model.fitting(nwtco_surv, plot_km = TRUE)
fit_res

## -----------------------------------------------------------------------------
print(fit_res$kmplot)

## -----------------------------------------------------------------------------
fit_res$aic_table

## -----------------------------------------------------------------------------
fit_res$best_model
fit_res$best_model_type

## -----------------------------------------------------------------------------
test_res <- run.cure.tests(nwtco_surv, dist = "lnorm")

## -----------------------------------------------------------------------------
test_res$mz

## -----------------------------------------------------------------------------
test_res$qn

## -----------------------------------------------------------------------------
test_res$shen

## -----------------------------------------------------------------------------
test_res$immune

## -----------------------------------------------------------------------------
test_res$receus

## -----------------------------------------------------------------------------
res_screen <- cure.appropriateness(
  data = nwtco_dat,
  time = "edrel",
  status = "rel",
  time_scale = "days_to_years",
  dist = "lnorm",
  plot_km = FALSE,
  run_tests = "no"
)
res_screen

## -----------------------------------------------------------------------------
res_screen$screening$aic_table
res_screen$screening$best_model
res_screen$screening$initial_decision

## -----------------------------------------------------------------------------
res_auto <- cure.appropriateness(
  data = nwtco_dat,
  time = "edrel",
  status = "rel",
  time_scale = "days_to_years",
  dist = "lnorm",
  plot_km = FALSE,
  run_tests = "auto"
)
res_auto

## -----------------------------------------------------------------------------
res_full <- cure.appropriateness(
  data = nwtco_dat,
  time = "edrel",
  status = "rel",
  time_scale = "days_to_years",
  dist = "lnorm",
  plot_km = FALSE,
  run_tests = "yes"
)
res_full

## -----------------------------------------------------------------------------
head(survival::gbsg)

## -----------------------------------------------------------------------------
gbsg_grouped <- survival::gbsg %>%
  mutate(
    meno_group = case_when(
      meno == 0 ~ "Pre",
      meno == 1 ~ "Post"
    )
  )

table(gbsg_grouped$meno_group)

## -----------------------------------------------------------------------------
gbsg_dat <- prepare.surv.data(
  data = survival::gbsg,
  time = "rfstime",
  status = "status",
  time_scale = "days_to_years"
)
head(gbsg_dat)

## -----------------------------------------------------------------------------
fit_res <- model.fitting(gbsg_dat, plot_km = TRUE)
fit_res

## -----------------------------------------------------------------------------
print(fit_res$kmplot)

## -----------------------------------------------------------------------------
fit_res$aic_table

## -----------------------------------------------------------------------------
fit_res$best_model
fit_res$best_model_type

## -----------------------------------------------------------------------------
test_res <- run.cure.tests(gbsg_dat, dist = "lnorm")

## -----------------------------------------------------------------------------
test_res$mz

## -----------------------------------------------------------------------------
test_res$qn

## -----------------------------------------------------------------------------
test_res$shen

## -----------------------------------------------------------------------------
test_res$immune

## -----------------------------------------------------------------------------
test_res$receus

## -----------------------------------------------------------------------------
res_screen <- cure.appropriateness(
  data = survival::gbsg,
  time = "rfstime",
  status = "status",
  time_scale = "days_to_years",
  dist = "lnorm",
  plot_km = FALSE,
  run_tests = "no"
)
res_screen

## -----------------------------------------------------------------------------
res_screen$screening$aic_table
res_screen$screening$best_model
res_screen$screening$initial_decision

## -----------------------------------------------------------------------------
res_auto <- cure.appropriateness(
  data = survival::gbsg,
  time = "rfstime",
  status = "status",
  time_scale = "days_to_years",
  dist = "lnorm",
  plot_km = FALSE,
  run_tests = "auto"
)
res_auto

## -----------------------------------------------------------------------------
res_full <- cure.appropriateness(
  data = survival::gbsg,
  time = "rfstime",
  status = "status",
  time_scale = "days_to_years",
  dist = "lnorm",
  plot_km = FALSE,
  run_tests = "yes"
)
res_full

